<?php

class HotelInfo extends CI_Model {

    function __construct()
    {
        
    }
    
    function hotelInfo(){
        
    }
}
?>
