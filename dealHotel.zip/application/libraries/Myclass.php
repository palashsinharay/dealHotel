<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Myclass {

    public function pala()
    {
        echo "pala";
    }
}

/* End of file Someclass.php */
